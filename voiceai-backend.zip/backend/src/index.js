require('dotenv').config()
const express = require('express')
const cors = require('cors')
const http = require('http')
const WebSocket = require('ws')
const path = require('path')
const fs = require('fs')

// ─── GOOGLE CREDENTIALS SETUP ────────────────────
// Handle credentials for Render deployment (JSON string env var)
if (process.env.GOOGLE_APPLICATION_CREDENTIALS_JSON && !process.env.GOOGLE_APPLICATION_CREDENTIALS) {
  const credPath = path.join(__dirname, '..', 'google-service-account.json')
  fs.writeFileSync(credPath, process.env.GOOGLE_APPLICATION_CREDENTIALS_JSON)
  process.env.GOOGLE_APPLICATION_CREDENTIALS = credPath
  console.log('✅ Google credentials written from env var')
}

// ─── IMPORTS ─────────────────────────────────────
const authRoutes = require('./routes/auth')
const campaignRoutes = require('./routes/campaigns')
const webhookRoutes = require('./routes/webhooks')
const db = require('./db/queries')
const { activeSessions, CallSession } = require('./call-engine/session')
const { getOAuthUrl, exchangeCodeForToken, setupSheetHeaders } = require('./integrations/googleSheets')

// ─── EXPRESS APP ─────────────────────────────────
const app = express()
const server = http.createServer(app)

// ─── MIDDLEWARE ───────────────────────────────────
app.use(cors({
  origin: [
    process.env.FRONTEND_URL || 'http://localhost:5173',
    'https://voiceai-india.vercel.app',  // Update with your Vercel URL
  ],
  credentials: true,
}))

app.use(express.json({ limit: '10mb' }))
app.use(express.urlencoded({ extended: true, limit: '10mb' }))

// Ensure uploads folder exists
const uploadsDir = path.join(__dirname, '..', 'uploads')
if (!fs.existsSync(uploadsDir)) fs.mkdirSync(uploadsDir, { recursive: true })

// ─── ROUTES ───────────────────────────────────────
app.use('/auth', authRoutes)
app.use('/campaigns', campaignRoutes)
app.use('/webhooks', webhookRoutes)

// ─── HEALTH CHECK ─────────────────────────────────
app.get('/health', (req, res) => {
  res.json({
    status: 'ok',
    time: new Date().toISOString(),
    activeCalls: activeSessions.size,
    env: process.env.NODE_ENV,
  })
})

// ─── GOOGLE SHEETS OAUTH ──────────────────────────
app.get('/auth/google/sheets', (req, res) => {
  const userId = req.query.user_id || req.query.state
  if (!userId) return res.status(400).send('user_id required')
  res.redirect(getOAuthUrl(userId))
})

app.get('/auth/google/callback', async (req, res) => {
  try {
    const { code, state: userId } = req.query
    if (!code || !userId) return res.status(400).send('Missing code or state')

    const token = await exchangeCodeForToken(code)
    await db.updateGoogleSheetsToken(userId, token)

    // Redirect back to frontend settings page
    const frontendUrl = process.env.FRONTEND_URL || 'http://localhost:5173'
    res.redirect(`${frontendUrl}/settings?sheets=connected`)
  } catch (err) {
    console.error('Google OAuth callback error:', err)
    const frontendUrl = process.env.FRONTEND_URL || 'http://localhost:5173'
    res.redirect(`${frontendUrl}/settings?sheets=error`)
  }
})

// ─── WEBSOCKET SERVER ─────────────────────────────
// Vobiz/Exotel connects here when a call is answered
// URL pattern: /ws/call/{sessionId}
const wss = new WebSocket.Server({ server, path: '/ws' })

wss.on('connection', async (ws, req) => {
  // Extract sessionId from URL: /ws/call/SESSION_ID
  const urlParts = req.url.split('/')
  const sessionId = urlParts[urlParts.length - 1]

  if (!sessionId) {
    console.log('[WS] No session ID in URL, closing connection')
    ws.close()
    return
  }

  console.log(`[WS] New connection: ${sessionId}`)

  // Find pre-created session (created in scheduler.js before call was made)
  let session = activeSessions.get(sessionId)

  if (session) {
    // Attach WebSocket to existing session and start the AI conversation
    session.wsSocket = ws
    await session.start()
  } else {
    // Session not found — try to look up from DB (edge case)
    console.log(`[WS] Session ${sessionId} not found in memory, checking DB...`)
    try {
      const result = await db.pool.query(
        `SELECT cl.*, con.phone, con.variables, con.campaign_id,
                camp.name, camp.language_priority, camp.script_content,
                camp.system_prompt, camp.persona_name, camp.persona_tone,
                camp.data_fields, camp.handoff_keywords, camp.caller_id,
                camp.user_id, camp.google_sheet_id, camp.campaign_type
         FROM call_logs cl
         JOIN contacts con ON cl.contact_id = con.id
         JOIN campaigns camp ON cl.campaign_id = camp.id
         WHERE cl.session_id = $1`,
        [sessionId]
      )

      if (result.rows[0]) {
        const row = result.rows[0]
        const contact = { id: row.contact_id, phone: row.phone, variables: row.variables }
        const campaign = {
          id: row.campaign_id,
          name: row.name,
          language_priority: row.language_priority,
          script_content: row.script_content,
          system_prompt: row.system_prompt,
          persona_name: row.persona_name,
          persona_tone: row.persona_tone,
          data_fields: row.data_fields,
          handoff_keywords: row.handoff_keywords,
          caller_id: row.caller_id,
          user_id: row.user_id,
          google_sheet_id: row.google_sheet_id,
          campaign_type: row.campaign_type,
        }
        session = new CallSession(contact, campaign, ws)
        session.sessionId = sessionId
        await session.start()
      } else {
        console.log(`[WS] No call log found for session ${sessionId}`)
        ws.close()
        return
      }
    } catch (err) {
      console.error('[WS] DB lookup error:', err)
      ws.close()
      return
    }
  }

  // ─── AUDIO INCOMING FROM TELEPHONY ───────────────
  ws.on('message', (data) => {
    const s = activeSessions.get(sessionId)
    if (s && s.isActive) {
      s.receiveAudio(data)
    }
  })

  // ─── CALL DISCONNECTED ────────────────────────────
  ws.on('close', async () => {
    console.log(`[WS] Disconnected: ${sessionId}`)
    const s = activeSessions.get(sessionId)
    if (s && s.isActive) {
      await s.endCall('disconnected')
    }
  })

  ws.on('error', (err) => {
    console.error(`[WS] Error for ${sessionId}:`, err.message)
  })
})

// ─── ERROR HANDLER ────────────────────────────────
app.use((err, req, res, next) => {
  console.error('Unhandled error:', err)
  res.status(500).json({ error: 'Internal server error' })
})

// ─── START SERVER ─────────────────────────────────
const PORT = process.env.PORT || 3000
server.listen(PORT, () => {
  console.log('\n================================================')
  console.log(`🚀 VoiceAI India Backend running on port ${PORT}`)
  console.log(`📱 Health check: http://localhost:${PORT}/health`)
  console.log(`🔌 WebSocket: ws://localhost:${PORT}/ws/call/{sessionId}`)
  console.log(`🌍 Environment: ${process.env.NODE_ENV}`)
  console.log('================================================\n')
})

// ─── GRACEFUL SHUTDOWN ────────────────────────────
process.on('SIGTERM', async () => {
  console.log('SIGTERM received — shutting down gracefully')
  // End all active calls
  for (const [id, session] of activeSessions) {
    await session.endCall('server_shutdown').catch(() => {})
  }
  server.close(() => process.exit(0))
})
