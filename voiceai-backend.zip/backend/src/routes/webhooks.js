const express = require('express')
const { activeSessions, CallSession } = require('../call-engine/session')
const { getStreamXML } = require('../telephony/exotel')
const db = require('../db/queries')

const router = express.Router()

// ─── VOBIZ WEBHOOK ───────────────────────────────
// Vobiz calls this URL for call status events
router.post('/vobiz', async (req, res) => {
  const { event, session_id, status, duration, recording_url, custom_data } = req.body
  const sessionId = session_id || custom_data?.session_id

  console.log(`[Vobiz Webhook] event=${event} session=${sessionId} status=${status}`)

  try {
    switch (event) {

      case 'call.initiated':
        // Call is ringing — nothing to do
        break

      case 'call.answered':
        // Call was answered — WebSocket should connect automatically
        // The session is already pre-created in scheduler.js
        break

      case 'call.no_answer':
        await handleCallEnd(sessionId, 'no_answer')
        break

      case 'call.busy':
        await handleCallEnd(sessionId, 'busy')
        break

      case 'call.failed':
        await handleCallEnd(sessionId, 'failed')
        break

      case 'call.ended':
        // Save recording URL if available
        if (recording_url && sessionId) {
          await db.updateCallLog(sessionId, { recording_url })
        }
        // End the session if still active
        const session = activeSessions.get(sessionId)
        if (session) {
          await session.endCall('completed')
        }
        break

      default:
        console.log(`[Vobiz Webhook] Unhandled event: ${event}`)
    }

    res.json({ status: 'ok' })
  } catch (err) {
    console.error('[Vobiz Webhook] Error:', err)
    res.status(500).json({ error: err.message })
  }
})

// ─── EXOTEL WEBHOOK — STREAM CONNECT ─────────────
// Called when Exotel answers a call — returns ExoML to connect audio stream
router.post('/exotel/stream/:sessionId', async (req, res) => {
  const { sessionId } = req.params
  const serverUrl = process.env.SERVER_URL || 'localhost:3000'

  console.log(`[Exotel] Stream connect for session: ${sessionId}`)

  res.set('Content-Type', 'text/xml')
  res.send(getStreamXML(sessionId, serverUrl))
})

// ─── EXOTEL WEBHOOK — STATUS EVENTS ──────────────
router.post('/exotel', async (req, res) => {
  const { CallSid, Status, RecordingUrl, Duration } = req.body

  console.log(`[Exotel Webhook] CallSid=${CallSid} Status=${Status}`)

  try {
    switch (Status) {
      case 'completed':
        if (RecordingUrl) {
          await db.updateCallLog(CallSid, { recording_url: RecordingUrl })
        }
        const session = activeSessions.get(CallSid)
        if (session) await session.endCall('completed')
        break

      case 'no-answer':
        await handleCallEnd(CallSid, 'no_answer')
        break

      case 'busy':
        await handleCallEnd(CallSid, 'busy')
        break

      case 'failed':
        await handleCallEnd(CallSid, 'failed')
        break
    }

    res.json({ status: 'ok' })
  } catch (err) {
    console.error('[Exotel Webhook] Error:', err)
    res.status(500).json({ error: err.message })
  }
})

// ─── HELPER ──────────────────────────────────────
async function handleCallEnd(sessionId, outcome) {
  if (!sessionId) return

  // If session is active, end it properly
  const session = activeSessions.get(sessionId)
  if (session) {
    await session.endCall(outcome)
    return
  }

  // Session not found (call never connected) — update log directly
  try {
    await db.updateCallLog(sessionId, {
      outcome,
      ended_at: new Date().toISOString(),
    })
  } catch (err) {
    // Call log might not exist if call failed before being created
    console.log(`[Webhook] Could not update call log for ${sessionId}: ${err.message}`)
  }
}

module.exports = router
