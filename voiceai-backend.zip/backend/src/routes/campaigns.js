const express = require('express')
const multer = require('multer')
const csv = require('csv-parser')
const fs = require('fs')
const pdfParse = require('pdf-parse')
const axios = require('axios')
const cheerio = require('cheerio')
const auth = require('../middleware/auth')
const db = require('../db/queries')
const { buildSystemPrompt } = require('../call-engine/prompts')
const { launchCampaign, pauseCampaign } = require('../jobs/scheduler')

const router = express.Router()

// Multer — save uploads temporarily
const upload = multer({
  dest: 'uploads/',
  limits: { fileSize: 10 * 1024 * 1024 }, // 10MB max
})

// ─── LIST ALL CAMPAIGNS ───────────────────────────
router.get('/', auth, async (req, res) => {
  try {
    const campaigns = await db.getCampaignsByUser(req.userId)
    res.json({ campaigns })
  } catch (err) {
    console.error('List campaigns error:', err)
    res.status(500).json({ error: err.message })
  }
})

// ─── GET SINGLE CAMPAIGN + STATS ─────────────────
router.get('/:id', auth, async (req, res) => {
  try {
    const campaign = await db.getCampaignById(req.params.id, req.userId)
    if (!campaign) return res.status(404).json({ error: 'Campaign not found' })

    const stats = await db.getCampaignStats(req.params.id)
    res.json({ campaign, stats })
  } catch (err) {
    res.status(500).json({ error: err.message })
  }
})

// ─── CREATE CAMPAIGN ──────────────────────────────
router.post('/', auth, async (req, res) => {
  try {
    const data = req.body

    if (!data.name) {
      return res.status(400).json({ error: 'Campaign name is required' })
    }

    // Auto-build system prompt from script
    if (!data.system_prompt && data.script_content) {
      data.system_prompt = buildSystemPrompt(data)
    }

    const campaign = await db.createCampaign(req.userId, data)
    console.log(`✅ Campaign created: ${campaign.name} by user ${req.userId}`)
    res.status(201).json({ campaign })
  } catch (err) {
    console.error('Create campaign error:', err)
    res.status(500).json({ error: err.message })
  }
})

// ─── UPDATE CAMPAIGN ──────────────────────────────
router.put('/:id', auth, async (req, res) => {
  try {
    const campaign = await db.updateCampaign(req.params.id, req.userId, req.body)
    if (!campaign) return res.status(404).json({ error: 'Campaign not found' })
    res.json({ campaign })
  } catch (err) {
    res.status(500).json({ error: err.message })
  }
})

// ─── UPLOAD CONTACTS CSV ──────────────────────────
router.post('/:id/contacts', auth, upload.single('file'), async (req, res) => {
  try {
    const campaign = await db.getCampaignById(req.params.id, req.userId)
    if (!campaign) return res.status(404).json({ error: 'Campaign not found' })
    if (!req.file) return res.status(400).json({ error: 'No file uploaded' })

    const contacts = []
    const errors = []

    await new Promise((resolve, reject) => {
      fs.createReadStream(req.file.path)
        .pipe(csv())
        .on('data', (row) => {
          // Accept 'phone', 'Phone', 'mobile', 'Mobile', 'number'
          const phone = row.phone || row.Phone || row.mobile || row.Mobile || row.number || row.Number
          if (!phone) {
            errors.push(`Row missing phone: ${JSON.stringify(row)}`)
            return
          }
          // Remove phone from variables, keep rest as template vars
          const { phone: _p, Phone: _P, mobile: _m, Mobile: _M, number: _n, Number: _N, ...variables } = row
          contacts.push({ phone: String(phone).trim(), variables })
        })
        .on('end', resolve)
        .on('error', reject)
    })

    // Cleanup temp file
    fs.unlinkSync(req.file.path)

    if (contacts.length === 0) {
      return res.status(400).json({ error: 'No valid contacts found in CSV. Make sure you have a "phone" column.' })
    }

    await db.bulkInsertContacts(req.params.id, contacts)

    console.log(`✅ Imported ${contacts.length} contacts for campaign ${req.params.id}`)
    res.json({
      message: `${contacts.length} contacts imported successfully`,
      count: contacts.length,
      errors: errors.slice(0, 5), // Return first 5 errors if any
    })
  } catch (err) {
    if (req.file) fs.unlinkSync(req.file.path).catch(() => {})
    console.error('Upload contacts error:', err)
    res.status(500).json({ error: err.message })
  }
})

// ─── EXTRACT SCRIPT FROM PDF ──────────────────────
router.post('/:id/script/pdf', auth, upload.single('file'), async (req, res) => {
  try {
    if (!req.file) return res.status(400).json({ error: 'No file uploaded' })

    const buffer = fs.readFileSync(req.file.path)
    const data = await pdfParse(buffer)
    fs.unlinkSync(req.file.path)

    const text = data.text.replace(/\s+/g, ' ').trim()
    res.json({ text: text.substring(0, 8000) }) // Limit to 8k chars
  } catch (err) {
    if (req.file) fs.unlinkSync(req.file.path)
    res.status(500).json({ error: 'PDF parsing failed: ' + err.message })
  }
})

// ─── EXTRACT SCRIPT FROM URL ──────────────────────
router.post('/:id/script/url', auth, async (req, res) => {
  try {
    const { url } = req.body
    if (!url) return res.status(400).json({ error: 'URL is required' })

    const response = await axios.get(url, {
      timeout: 10000,
      headers: { 'User-Agent': 'Mozilla/5.0 (compatible; VoiceAI/1.0)' },
    })

    const $ = cheerio.load(response.data)
    // Remove noise elements
    $('script, style, nav, footer, header, iframe, .cookie-banner, .ad').remove()

    const text = $('body').text()
      .replace(/\s+/g, ' ')
      .replace(/\n+/g, '\n')
      .trim()

    res.json({ text: text.substring(0, 8000) })
  } catch (err) {
    res.status(500).json({ error: 'Could not fetch URL: ' + err.message })
  }
})

// ─── LAUNCH CAMPAIGN ──────────────────────────────
router.post('/:id/launch', auth, async (req, res) => {
  try {
    const campaign = await db.getCampaignById(req.params.id, req.userId)
    if (!campaign) return res.status(404).json({ error: 'Campaign not found' })

    if (campaign.status === 'active') {
      return res.status(400).json({ error: 'Campaign is already active' })
    }

    if (campaign.total_contacts === 0) {
      return res.status(400).json({ error: 'No contacts uploaded. Please upload a CSV first.' })
    }

    await db.updateCampaignStatus(req.params.id, 'active')
    await launchCampaign(campaign)

    console.log(`🚀 Campaign launched: ${campaign.name}`)
    res.json({ message: 'Campaign launched successfully', campaign_id: req.params.id })
  } catch (err) {
    console.error('Launch campaign error:', err)
    res.status(500).json({ error: err.message })
  }
})

// ─── PAUSE CAMPAIGN ───────────────────────────────
router.post('/:id/pause', auth, async (req, res) => {
  try {
    const campaign = await db.getCampaignById(req.params.id, req.userId)
    if (!campaign) return res.status(404).json({ error: 'Campaign not found' })

    await db.updateCampaignStatus(req.params.id, 'paused')
    await pauseCampaign(req.params.id)

    console.log(`⏸️ Campaign paused: ${campaign.name}`)
    res.json({ message: 'Campaign paused' })
  } catch (err) {
    res.status(500).json({ error: err.message })
  }
})

// ─── GET CAMPAIGN STATS ───────────────────────────
router.get('/:id/stats', auth, async (req, res) => {
  try {
    const stats = await db.getCampaignStats(req.params.id)
    res.json({ stats })
  } catch (err) {
    res.status(500).json({ error: err.message })
  }
})

// ─── GET CALL LOGS ────────────────────────────────
router.get('/:id/calls', auth, async (req, res) => {
  try {
    const limit = parseInt(req.query.limit) || 50
    const offset = parseInt(req.query.offset) || 0
    const logs = await db.getCallLogsByCampaign(req.params.id, limit, offset)
    res.json({ logs })
  } catch (err) {
    res.status(500).json({ error: err.message })
  }
})

module.exports = router
