const { Queue, Worker } = require('bullmq')
const Redis = require('ioredis')
const { v4: uuidv4 } = require('uuid')
const db = require('../db/queries')
const { makeOutboundCall } = require('../telephony/vobiz')
const { CallSession, activeSessions } = require('../call-engine/session')

// ─── REDIS CONNECTION ────────────────────────────
const redisConnection = new Redis(process.env.REDIS_URL, {
  maxRetriesPerRequest: null,
  enableReadyCheck: false,
  tls: process.env.REDIS_URL?.startsWith('rediss://') ? {} : undefined,
})

redisConnection.on('connect', () => console.log('✅ Redis connected'))
redisConnection.on('error', (err) => console.error('❌ Redis error:', err.message))

// ─── QUEUE ───────────────────────────────────────
const callQueue = new Queue('calls', {
  connection: redisConnection,
  defaultJobOptions: {
    removeOnComplete: 100,  // Keep last 100 completed jobs
    removeOnFail: 200,       // Keep last 200 failed jobs
  },
})

// Track which campaigns are actively running
const activeCampaigns = new Set()

// ─── WORKER ──────────────────────────────────────
// This processes each individual call job
const callWorker = new Worker('calls', async (job) => {
  const { contactId, campaignId, sessionId } = job.data

  // Fetch fresh data
  const [campaignResult, contactResult] = await Promise.all([
    db.pool.query('SELECT * FROM campaigns WHERE id = $1', [campaignId]),
    db.pool.query('SELECT * FROM contacts WHERE id = $1', [contactId]),
  ])

  const campaign = campaignResult.rows[0]
  const contact = contactResult.rows[0]

  if (!campaign || !contact) {
    console.log(`[Worker] Skipping — campaign or contact not found`)
    return
  }

  // Stop if campaign was paused
  if (campaign.status !== 'active') {
    console.log(`[Worker] Skipping — campaign ${campaign.name} is ${campaign.status}`)
    return
  }

  // Check calling hours (TRAI compliance: 9 AM – 9 PM IST)
  const nowIST = new Date(new Date().toLocaleString('en-US', { timeZone: 'Asia/Kolkata' }))
  const currentHour = nowIST.getHours()
  const startHour = parseInt((campaign.calling_hours_start || '09:00').split(':')[0])
  const endHour = parseInt((campaign.calling_hours_end || '21:00').split(':')[0])

  if (currentHour < startHour || currentHour >= endHour) {
    const delayMs = getDelayToNextWindow(startHour)
    console.log(`[Worker] Outside calling hours (${currentHour}:xx). Delaying ${Math.round(delayMs / 60000)} mins.`)
    // Re-queue for next window
    await callQueue.add('call', job.data, { delay: delayMs })
    return
  }

  // Mark contact as calling
  await db.pool.query(
    "UPDATE contacts SET status = 'calling' WHERE id = $1",
    [contactId]
  )

  try {
    const serverUrl = process.env.SERVER_URL || 'localhost:3000'

    // Pre-create the session so it's ready when WebSocket connects
    const session = new CallSession(contact, campaign, null)
    session.sessionId = sessionId
    activeSessions.set(sessionId, session)

    // Make the actual phone call
    await makeOutboundCall(
      campaign.caller_id,
      contact.phone,
      sessionId,
      serverUrl
    )

    console.log(`[Worker] 📞 Called ${contact.phone} for "${campaign.name}"`)
  } catch (err) {
    console.error(`[Worker] Call failed for ${contact.phone}:`, err.message)
    // Clean up failed session
    activeSessions.delete(sessionId)
    await db.updateContactStatus(contactId, 'failed', 'call_failed')
  }

}, {
  connection: redisConnection,
  concurrency: parseInt(process.env.MAX_CONCURRENT_CALLS) || 5,
})

callWorker.on('completed', (job) => {
  console.log(`[Worker] Job ${job.id} completed`)
})

callWorker.on('failed', (job, err) => {
  console.error(`[Worker] Job ${job?.id} failed:`, err.message)
})

// ─── LAUNCH CAMPAIGN ─────────────────────────────
async function launchCampaign(campaign) {
  activeCampaigns.add(campaign.id)
  console.log(`[Scheduler] 🚀 Launching campaign: ${campaign.name}`)

  // Queue all pending contacts in batches
  const BATCH_SIZE = 100
  let offset = 0

  while (activeCampaigns.has(campaign.id)) {
    const contacts = await db.getPendingContacts(campaign.id, BATCH_SIZE)

    if (contacts.length === 0) {
      console.log(`[Scheduler] No more pending contacts for: ${campaign.name}`)
      break
    }

    for (let i = 0; i < contacts.length; i++) {
      const contact = contacts[i]
      const sessionId = `${campaign.id.split('-')[0]}-${contact.id.split('-')[0]}-${Date.now()}`

      await callQueue.add('call', {
        contactId: contact.id,
        campaignId: campaign.id,
        sessionId,
      }, {
        // Stagger calls by 2 seconds each to avoid spam detection
        delay: i * 2000,
        attempts: campaign.max_retries + 1,
        backoff: {
          type: 'fixed',
          delay: (campaign.retry_gap_minutes || 30) * 60 * 1000,
        },
      })
    }

    console.log(`[Scheduler] Queued ${contacts.length} calls for: ${campaign.name}`)
    offset += BATCH_SIZE

    // Small pause between batches
    await new Promise(r => setTimeout(r, 500))
  }
}

// ─── PAUSE CAMPAIGN ──────────────────────────────
async function pauseCampaign(campaignId) {
  activeCampaigns.delete(campaignId)
  console.log(`[Scheduler] ⏸️ Campaign ${campaignId} paused`)
  // Note: Already queued jobs will still run unless you drain the queue
  // For MVP, we just stop adding new jobs
}

// ─── PROCESS SCHEDULED CALLBACKS ─────────────────
// Runs every minute to check for callbacks that need to be made
async function processCallbacks() {
  try {
    const callbacks = await db.getPendingCallbacks()

    for (const cb of callbacks) {
      const campaign = await db.getCampaignByIdOnly(cb.campaign_id)
      if (!campaign || campaign.status !== 'active') continue

      const sessionId = `callback-${cb.id.split('-')[0]}-${Date.now()}`

      await callQueue.add('call', {
        contactId: cb.contact_id,
        campaignId: cb.campaign_id,
        sessionId,
      })

      await db.markCallbackQueued(cb.id)
      console.log(`[Scheduler] 📅 Callback queued for contact ${cb.contact_id}`)
    }
  } catch (err) {
    console.error('[Scheduler] Callback processing error:', err.message)
  }
}

// Check callbacks every 60 seconds
setInterval(processCallbacks, 60 * 1000)

// ─── HELPER ──────────────────────────────────────
function getDelayToNextWindow(startHour) {
  const now = new Date()
  const nextWindow = new Date()
  nextWindow.setHours(startHour, 0, 0, 0)

  // If next window is in the past, move to tomorrow
  if (nextWindow <= now) {
    nextWindow.setDate(nextWindow.getDate() + 1)
  }

  return nextWindow.getTime() - now.getTime()
}

module.exports = { launchCampaign, pauseCampaign, callQueue }
