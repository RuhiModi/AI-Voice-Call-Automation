const { Pool } = require('pg')
require('dotenv').config()

const pool = new Pool({
  connectionString: process.env.DATABASE_URL,
  ssl: { rejectUnauthorized: false },
  max: 10,
  idleTimeoutMillis: 30000,
  connectionTimeoutMillis: 2000,
})

// Test connection on startup
pool.connect((err, client, release) => {
  if (err) {
    console.error('❌ Database connection error:', err.message)
  } else {
    console.log('✅ Database connected successfully')
    release()
  }
})

module.exports = {

  // ============================================
  // USERS
  // ============================================

  async createUser(email, passwordHash, companyName) {
    const res = await pool.query(
      `INSERT INTO users (email, password_hash, company_name)
       VALUES ($1, $2, $3)
       RETURNING id, email, company_name, plan, created_at`,
      [email, passwordHash, companyName]
    )
    return res.rows[0]
  },

  async getUserByEmail(email) {
    const res = await pool.query(
      'SELECT * FROM users WHERE email = $1',
      [email]
    )
    return res.rows[0]
  },

  async getUserById(id) {
    const res = await pool.query(
      'SELECT id, email, company_name, plan, google_sheets_token, created_at FROM users WHERE id = $1',
      [id]
    )
    return res.rows[0]
  },

  async updateGoogleSheetsToken(userId, token) {
    await pool.query(
      'UPDATE users SET google_sheets_token = $1 WHERE id = $2',
      [JSON.stringify(token), userId]
    )
  },

  // ============================================
  // CAMPAIGNS
  // ============================================

  async createCampaign(userId, data) {
    const res = await pool.query(
      `INSERT INTO campaigns
       (user_id, name, description, campaign_type, language_priority,
        script_type, script_content, system_prompt, persona_name, persona_tone,
        data_fields, handoff_keywords, caller_id, max_concurrent_calls,
        max_retries, retry_gap_minutes, calling_hours_start, calling_hours_end,
        google_sheet_id, google_sheet_url, schedule_start, status)
       VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15,$16,$17,$18,$19,$20,$21,$22)
       RETURNING *`,
      [
        userId,
        data.name,
        data.description || null,
        data.campaign_type || 'custom',
        data.language_priority || 'gu',
        data.script_type || 'manual',
        data.script_content || null,
        data.system_prompt || null,
        data.persona_name || 'Priya',
        data.persona_tone || 'friendly',
        JSON.stringify(data.data_fields || []),
        JSON.stringify(data.handoff_keywords || ['human', 'agent', 'manager', 'transfer']),
        data.caller_id || null,
        data.max_concurrent_calls || 5,
        data.max_retries || 2,
        data.retry_gap_minutes || 30,
        data.calling_hours_start || '09:00',
        data.calling_hours_end || '21:00',
        data.google_sheet_id || null,
        data.google_sheet_url || null,
        data.schedule_start || null,
        data.status || 'draft',
      ]
    )
    return res.rows[0]
  },

  async getCampaignsByUser(userId) {
    const res = await pool.query(
      'SELECT * FROM campaigns WHERE user_id = $1 ORDER BY created_at DESC',
      [userId]
    )
    return res.rows
  },

  async getCampaignById(id, userId) {
    const res = await pool.query(
      'SELECT * FROM campaigns WHERE id = $1 AND user_id = $2',
      [id, userId]
    )
    return res.rows[0]
  },

  async getCampaignByIdOnly(id) {
    const res = await pool.query(
      'SELECT * FROM campaigns WHERE id = $1',
      [id]
    )
    return res.rows[0]
  },

  async updateCampaign(id, userId, data) {
    const allowed = [
      'name', 'description', 'campaign_type', 'language_priority',
      'script_type', 'script_content', 'system_prompt', 'persona_name',
      'persona_tone', 'data_fields', 'caller_id', 'max_concurrent_calls',
      'max_retries', 'retry_gap_minutes', 'calling_hours_start',
      'calling_hours_end', 'google_sheet_id', 'google_sheet_url', 'schedule_start'
    ]
    const keys = Object.keys(data).filter(k => allowed.includes(k))
    if (keys.length === 0) return null

    const fields = keys.map((k, i) => `${k} = $${i + 3}`).join(', ')
    const values = keys.map(k =>
      ['data_fields', 'handoff_keywords'].includes(k)
        ? JSON.stringify(data[k])
        : data[k]
    )

    const res = await pool.query(
      `UPDATE campaigns SET ${fields}, updated_at = NOW()
       WHERE id = $1 AND user_id = $2 RETURNING *`,
      [id, userId, ...values]
    )
    return res.rows[0]
  },

  async updateCampaignStatus(id, status) {
    await pool.query(
      'UPDATE campaigns SET status = $1, updated_at = NOW() WHERE id = $2',
      [status, id]
    )
  },

  async incrementCompletedCalls(campaignId) {
    await pool.query(
      'UPDATE campaigns SET completed_calls = completed_calls + 1 WHERE id = $1',
      [campaignId]
    )
  },

  // ============================================
  // CONTACTS
  // ============================================

  async bulkInsertContacts(campaignId, contacts) {
    const client = await pool.connect()
    try {
      await client.query('BEGIN')

      // Delete existing pending contacts if re-uploading
      await client.query(
        "DELETE FROM contacts WHERE campaign_id = $1 AND status = 'pending'",
        [campaignId]
      )

      for (const c of contacts) {
        // Clean phone number — keep only digits, add +91 if 10 digit
        let phone = c.phone.replace(/\D/g, '')
        if (phone.length === 10) phone = '91' + phone
        if (!phone.startsWith('+')) phone = '+' + phone

        await client.query(
          'INSERT INTO contacts (campaign_id, phone, variables) VALUES ($1, $2, $3)',
          [campaignId, phone, JSON.stringify(c.variables || {})]
        )
      }

      await client.query(
        `UPDATE campaigns SET total_contacts = (
          SELECT COUNT(*) FROM contacts WHERE campaign_id = $1
        ) WHERE id = $1`,
        [campaignId]
      )

      await client.query('COMMIT')
    } catch (e) {
      await client.query('ROLLBACK')
      throw e
    } finally {
      client.release()
    }
  },

  async getPendingContacts(campaignId, limit = 10) {
    const res = await pool.query(
      `SELECT * FROM contacts
       WHERE campaign_id = $1
         AND status = 'pending'
         AND do_not_call = FALSE
         AND (next_call_at IS NULL OR next_call_at <= NOW())
       ORDER BY created_at ASC
       LIMIT $2`,
      [campaignId, limit]
    )
    return res.rows
  },

  async updateContactStatus(id, status, outcome = null) {
    await pool.query(
      `UPDATE contacts
       SET status = $1, last_outcome = $2, call_count = call_count + 1
       WHERE id = $3`,
      [status, outcome, id]
    )
  },

  async scheduleContactCallback(id, scheduledAt) {
    await pool.query(
      "UPDATE contacts SET status = 'scheduled', next_call_at = $1 WHERE id = $2",
      [scheduledAt, id]
    )
  },

  async markDNC(contactId) {
    await pool.query(
      "UPDATE contacts SET do_not_call = TRUE, status = 'dnc' WHERE id = $1",
      [contactId]
    )
  },

  // ============================================
  // CALL LOGS
  // ============================================

  async createCallLog(contactId, campaignId, sessionId) {
    const res = await pool.query(
      `INSERT INTO call_logs (contact_id, campaign_id, session_id)
       VALUES ($1, $2, $3)
       ON CONFLICT (session_id) DO NOTHING
       RETURNING *`,
      [contactId, campaignId, sessionId]
    )
    return res.rows[0]
  },

  async updateCallLog(sessionId, data) {
    const allowed = [
      'outcome', 'duration_sec', 'language_detected',
      'transcript', 'collected_data', 'recording_url', 'ended_at'
    ]
    const keys = Object.keys(data).filter(k => allowed.includes(k))
    if (keys.length === 0) return

    const fields = keys.map((k, i) => `${k} = $${i + 2}`).join(', ')
    const values = keys.map(k =>
      ['transcript', 'collected_data'].includes(k)
        ? (typeof data[k] === 'string' ? data[k] : JSON.stringify(data[k]))
        : data[k]
    )

    await pool.query(
      `UPDATE call_logs SET ${fields} WHERE session_id = $1`,
      [sessionId, ...values]
    )
  },

  async getCallLogsByCampaign(campaignId, limit = 50, offset = 0) {
    const res = await pool.query(
      `SELECT cl.*, c.phone, c.variables
       FROM call_logs cl
       JOIN contacts c ON cl.contact_id = c.id
       WHERE cl.campaign_id = $1
       ORDER BY cl.started_at DESC
       LIMIT $2 OFFSET $3`,
      [campaignId, limit, offset]
    )
    return res.rows
  },

  async getCampaignStats(campaignId) {
    const res = await pool.query(
      `SELECT
        COUNT(*) FILTER (WHERE status = 'completed') as completed,
        COUNT(*) FILTER (WHERE status = 'pending') as pending,
        COUNT(*) FILTER (WHERE status = 'failed') as failed,
        COUNT(*) FILTER (WHERE status = 'calling') as calling,
        COUNT(*) FILTER (WHERE status = 'scheduled') as scheduled,
        COUNT(*) FILTER (WHERE last_outcome = 'busy') as busy,
        COUNT(*) FILTER (WHERE last_outcome = 'no_answer') as no_answer,
        COUNT(*) FILTER (WHERE last_outcome = 'transferred') as transferred,
        COUNT(*) FILTER (WHERE do_not_call = TRUE) as dnc
       FROM contacts
       WHERE campaign_id = $1`,
      [campaignId]
    )
    return res.rows[0]
  },

  // ============================================
  // CALLBACKS
  // ============================================

  async getPendingCallbacks() {
    const res = await pool.query(
      `SELECT cb.*, c.campaign_id
       FROM callbacks cb
       JOIN contacts c ON cb.contact_id = c.id
       WHERE cb.status = 'pending'
         AND cb.scheduled_at <= NOW()
       LIMIT 20`
    )
    return res.rows
  },

  async markCallbackQueued(id) {
    await pool.query(
      "UPDATE callbacks SET status = 'queued' WHERE id = $1",
      [id]
    )
  },

  // Expose pool for raw queries when needed
  pool,
}
