const OpenAI = require('openai')

const openai = new OpenAI({
  apiKey: process.env.OPENAI_API_KEY,
})

/**
 * Get AI response for a user utterance.
 * Returns structured JSON with text + action.
 *
 * @param {string} systemPrompt - Built by prompts.js
 * @param {Array} history - Conversation so far [{role, content}]
 * @param {string} userText - What user just said
 * @returns {Object} { text, action, reschedule_time, collected_data, detected_language }
 */
async function getAIResponse(systemPrompt, history, userText) {
  try {
    // Keep last 10 turns to save tokens
    const trimmedHistory = history.slice(-10)

    const completion = await openai.chat.completions.create({
      model: 'gpt-4o-mini',
      messages: [
        { role: 'system', content: systemPrompt },
        ...trimmedHistory,
        { role: 'user', content: userText },
      ],
      response_format: { type: 'json_object' },
      max_tokens: 300,
      temperature: 0.7,
    })

    const content = completion.choices[0].message.content
    const parsed = JSON.parse(content)

    return {
      text: parsed.text || 'માફ કરો, ફરી પ્રયાસ કરો.',
      action: parsed.action || 'continue',
      reschedule_time: parsed.reschedule_time || null,
      collected_data: parsed.collected_data || {},
      detected_language: parsed.detected_language || 'gu',
    }
  } catch (err) {
    console.error('[LLM] Error:', err.message)
    // Fallback response so call doesn't break
    return {
      text: 'Sorry, there was a technical issue. Please hold on.',
      action: 'continue',
      collected_data: {},
      detected_language: 'gu',
    }
  }
}

/**
 * Parse a natural language reschedule time into ISO datetime.
 * e.g. "tomorrow 3pm" → "2024-01-16T15:00:00.000Z"
 */
async function parseRescheduleTime(naturalText) {
  if (!naturalText) return null

  try {
    const now = new Date().toISOString()
    const completion = await openai.chat.completions.create({
      model: 'gpt-4o-mini',
      messages: [{
        role: 'user',
        content: `Parse this reschedule request into an ISO datetime.
Current time: ${now}
User said: "${naturalText}"
Return ONLY valid JSON: { "datetime": "<ISO 8601 string>" }
If you cannot parse it, return: { "datetime": null }`,
      }],
      response_format: { type: 'json_object' },
      max_tokens: 60,
      temperature: 0,
    })

    const parsed = JSON.parse(completion.choices[0].message.content)
    return parsed.datetime || null
  } catch {
    return null
  }
}

module.exports = { getAIResponse, parseRescheduleTime }
