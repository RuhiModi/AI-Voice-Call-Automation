const textToSpeech = require('@google-cloud/text-to-speech')

// Handle credentials same way as STT
function getGoogleCredentials() {
  if (process.env.GOOGLE_APPLICATION_CREDENTIALS_JSON) {
    return JSON.parse(process.env.GOOGLE_APPLICATION_CREDENTIALS_JSON)
  }
  return undefined
}

const clientOptions = {}
const creds = getGoogleCredentials()
if (creds) clientOptions.credentials = creds

const ttsClient = new textToSpeech.TextToSpeechClient(clientOptions)

// Voice configurations per language
// Using Neural2 voices for best quality Indian accents
const VOICES = {
  gu: {
    languageCode: 'gu-IN',
    name: 'gu-IN-Standard-A',   // Gujarati female (Neural2 not yet available for Gujarati)
    ssmlGender: 'FEMALE',
  },
  hi: {
    languageCode: 'hi-IN',
    name: 'hi-IN-Neural2-A',    // Hindi female Neural2 — best quality
    ssmlGender: 'FEMALE',
  },
  en: {
    languageCode: 'en-IN',
    name: 'en-IN-Neural2-A',    // Indian English female Neural2
    ssmlGender: 'FEMALE',
  },
}

// Simple cache to avoid re-generating same audio (saves cost)
const audioCache = new Map()
const MAX_CACHE_SIZE = 200

/**
 * Convert text to audio buffer.
 * Returns PCM 8kHz 16-bit mono (matches telephony format).
 */
async function textToAudio(text, lang = 'gu') {
  const cacheKey = `${lang}:${text}`
  if (audioCache.has(cacheKey)) {
    return audioCache.get(cacheKey)
  }

  const voice = VOICES[lang] || VOICES.gu

  const request = {
    input: { text: text.substring(0, 500) }, // Limit to 500 chars per chunk
    voice,
    audioConfig: {
      audioEncoding: 'LINEAR16',
      sampleRateHertz: 8000,    // Match telephony sample rate
      effectsProfileId: ['telephony-class-application'],
      pitch: 0,
      speakingRate: 0.9,         // Slightly slower for phone clarity
    },
  }

  try {
    const [response] = await ttsClient.synthesizeSpeech(request)
    const audio = response.audioContent

    // Cache smaller responses only
    if (audio.length < 100000 && audioCache.size < MAX_CACHE_SIZE) {
      audioCache.set(cacheKey, audio)
    }

    return audio
  } catch (err) {
    console.error('[TTS] Error:', err.message)
    throw err
  }
}

/**
 * Stream TTS audio to a WebSocket connection.
 * Splits text into sentences for faster first-byte delivery.
 * User hears first sentence in ~300ms instead of waiting for full response.
 */
async function streamTTSToSocket(text, lang, wsSocket) {
  if (!text || !wsSocket || wsSocket.readyState !== 1) return

  // Split into sentences for streaming
  const sentences = text
    .split(/(?<=[।।!?.]+)\s+/)
    .map(s => s.trim())
    .filter(Boolean)

  for (const sentence of sentences) {
    if (wsSocket.readyState !== 1) break // Socket closed
    try {
      const audio = await textToAudio(sentence, lang)
      wsSocket.send(audio)
    } catch (err) {
      console.error('[TTS] Failed to stream sentence:', sentence, err.message)
    }
  }
}

module.exports = { textToAudio, streamTTSToSocket, VOICES }
