const { v4: uuidv4 } = require('uuid')
const { createSTTStream, VoiceActivityDetector } = require('./stt')
const { streamTTSToSocket } = require('./tts')
const { getAIResponse, parseRescheduleTime } = require('./llm')
const { buildSystemPrompt, buildGreeting } = require('./prompts')
const db = require('../db/queries')
const { appendToGoogleSheet } = require('../integrations/googleSheets')

// All active call sessions — key: sessionId, value: CallSession
const activeSessions = new Map()

class CallSession {
  constructor(contact, campaign, wsSocket) {
    this.sessionId = uuidv4()
    this.contact = contact
    this.campaign = campaign
    this.wsSocket = wsSocket

    this.language = campaign.language_priority || 'gu'
    this.transcript = []         // Full conversation history
    this.collectedData = {}      // Data collected during call
    this.isActive = true
    this.startTime = Date.now()

    this.sttStream = null
    this.vad = null
    this.audioBuffer = Buffer.alloc(0)
  }

  // ─── START CALL ─────────────────────────────────
  async start() {
    console.log(`[Session ${this.sessionId}] 📞 Starting call to ${this.contact.phone}`)

    try {
      // Create call log in database
      await db.createCallLog(this.contact.id, this.campaign.id, this.sessionId)

      // Play opening greeting
      const greeting = buildGreeting(this.campaign, this.contact, this.language)
      await this.speak(greeting)

      // Add greeting to transcript
      this.transcript.push({ role: 'assistant', content: greeting })

      // Setup STT + VAD
      this.setupSTT()
      this.setupVAD()

      // Register in active sessions map
      activeSessions.set(this.sessionId, this)
    } catch (err) {
      console.error(`[Session ${this.sessionId}] Start error:`, err)
      await this.endCall('failed')
    }
  }

  // ─── SETUP SPEECH-TO-TEXT STREAM ────────────────
  setupSTT() {
    this.sttStream = createSTTStream(
      async (text, detectedLang) => {
        if (!this.isActive) return

        // Update language based on detection
        this.language = detectedLang
        console.log(`[Session ${this.sessionId}] User (${detectedLang}): "${text}"`)

        // Add to transcript
        this.transcript.push({ role: 'user', content: text })

        // Get AI response
        await this.processUserInput(text)
      },
      async (err) => {
        console.error(`[Session ${this.sessionId}] STT error:`, err.message)
        // Restart STT stream on recoverable errors
        if (this.isActive && err.code !== 11) {
          setTimeout(() => {
            if (this.isActive) this.setupSTT()
          }, 1000)
        }
      }
    )
  }

  // ─── SETUP VOICE ACTIVITY DETECTOR ──────────────
  setupVAD() {
    this.vad = new VoiceActivityDetector(() => {
      // User stopped speaking — flush remaining audio to STT
      if (this.audioBuffer.length > 0 && this.sttStream && !this.sttStream.destroyed) {
        this.sttStream.write(this.audioBuffer)
        this.audioBuffer = Buffer.alloc(0)
      }
    }, 900)
  }

  // ─── RECEIVE AUDIO FROM WEBSOCKET ───────────────
  receiveAudio(audioData) {
    if (!this.isActive) return

    const buffer = Buffer.isBuffer(audioData) ? audioData : Buffer.from(audioData)

    // Process through VAD
    this.vad?.processChunk(buffer)

    // Buffer audio
    this.audioBuffer = Buffer.concat([this.audioBuffer, buffer])

    // Send to STT in 200ms chunks (3200 bytes at 8kHz 16-bit)
    const CHUNK_SIZE = 3200
    while (this.audioBuffer.length >= CHUNK_SIZE) {
      if (this.sttStream && !this.sttStream.destroyed) {
        this.sttStream.write(this.audioBuffer.slice(0, CHUNK_SIZE))
      }
      this.audioBuffer = this.audioBuffer.slice(CHUNK_SIZE)
    }
  }

  // ─── PROCESS USER INPUT THROUGH LLM ─────────────
  async processUserInput(userText) {
    try {
      // Build fresh system prompt with current language
      const systemPrompt = buildSystemPrompt(this.campaign, this.contact, this.language)

      // Build conversation history for LLM
      const history = this.transcript.slice(-10).map(t => ({
        role: t.role,
        content: t.content,
      }))

      // Get AI response
      const response = await getAIResponse(systemPrompt, history, userText)

      // Update language if AI detected a change
      if (response.detected_language) {
        this.language = response.detected_language
      }

      // Merge newly collected data
      this.collectedData = { ...this.collectedData, ...response.collected_data }

      // Add AI response to transcript
      this.transcript.push({ role: 'assistant', content: response.text })

      console.log(`[Session ${this.sessionId}] AI (${this.language}): "${response.text}" [action: ${response.action}]`)

      // Speak the response
      await this.speak(response.text)

      // Handle action
      await this.handleAction(response)
    } catch (err) {
      console.error(`[Session ${this.sessionId}] Process input error:`, err)
    }
  }

  // ─── SPEAK TEXT THROUGH TTS ─────────────────────
  async speak(text) {
    if (!this.isActive || !text) return
    try {
      await streamTTSToSocket(text, this.language, this.wsSocket)
    } catch (err) {
      console.error(`[Session ${this.sessionId}] Speak error:`, err.message)
    }
  }

  // ─── HANDLE ACTION FROM LLM ─────────────────────
  async handleAction({ action, reschedule_time }) {
    switch (action) {
      case 'reschedule': {
        const scheduledAt = await parseRescheduleTime(reschedule_time)
        if (scheduledAt) {
          await db.scheduleContactCallback(this.contact.id, scheduledAt)
          // Also insert into callbacks table for the scheduler to pick up
          await db.pool.query(
            'INSERT INTO callbacks (contact_id, campaign_id, scheduled_at, reason) VALUES ($1, $2, $3, $4)',
            [this.contact.id, this.campaign.id, scheduledAt, reschedule_time]
          )
          console.log(`[Session ${this.sessionId}] 📅 Callback scheduled for: ${scheduledAt}`)
        }
        await this.endCall('rescheduled')
        break
      }

      case 'transfer': {
        await this.transferToHuman()
        break
      }

      case 'dnc': {
        await db.markDNC(this.contact.id)
        console.log(`[Session ${this.sessionId}] 🚫 Contact marked DNC: ${this.contact.phone}`)
        await this.endCall('dnc')
        break
      }

      case 'end': {
        await this.endCall('completed')
        break
      }

      case 'continue':
      default:
        // Do nothing — wait for user's next response
        break
    }
  }

  // ─── TRANSFER TO HUMAN AGENT ─────────────────────
  async transferToHuman() {
    const agentNumber = process.env.HUMAN_AGENT_NUMBER
    if (agentNumber) {
      try {
        const { transferCall } = require('../telephony/vobiz')
        await transferCall(this.sessionId, agentNumber)
        console.log(`[Session ${this.sessionId}] 👤 Transferring to human: ${agentNumber}`)
      } catch (err) {
        console.error(`[Session ${this.sessionId}] Transfer failed:`, err.message)
      }
    }
    await this.endCall('transferred')
  }

  // ─── END CALL AND SAVE DATA ───────────────────────
  async endCall(outcome = 'completed') {
    if (!this.isActive) return
    this.isActive = false

    const duration = Math.floor((Date.now() - this.startTime) / 1000)
    console.log(`[Session ${this.sessionId}] 📵 Call ended: ${outcome} (${duration}s)`)

    try {
      // Update call log
      await db.updateCallLog(this.sessionId, {
        outcome,
        duration_sec: duration,
        language_detected: this.language,
        transcript: JSON.stringify(this.transcript),
        collected_data: JSON.stringify(this.collectedData),
        ended_at: new Date().toISOString(),
      })

      // Update contact status
      await db.updateContactStatus(this.contact.id, 'completed', outcome)

      // Increment campaign completed count
      await db.incrementCompletedCalls(this.campaign.id)

      // Write to Google Sheets if configured
      if (this.campaign.google_sheet_id) {
        const user = await db.getUserById(this.campaign.user_id)
        if (user?.google_sheets_token) {
          await appendToGoogleSheet(
            user.google_sheets_token,
            this.campaign.google_sheet_id,
            this.contact,
            outcome,
            this.language,
            duration,
            this.collectedData
          ).catch(err => console.error('Google Sheets error:', err.message))
        }
      }

      // Check if campaign is fully complete
      const stats = await db.getCampaignStats(this.campaign.id)
      const pending = parseInt(stats.pending) + parseInt(stats.calling) + parseInt(stats.scheduled)
      if (pending === 0 && this.campaign.status === 'active') {
        await db.updateCampaignStatus(this.campaign.id, 'completed')
        console.log(`✅ Campaign completed: ${this.campaign.name}`)
      }
    } catch (err) {
      console.error(`[Session ${this.sessionId}] End call save error:`, err)
    } finally {
      // Cleanup
      this.sttStream?.destroy()
      this.vad?.destroy()
      activeSessions.delete(this.sessionId)
    }
  }
}

module.exports = { CallSession, activeSessions }
