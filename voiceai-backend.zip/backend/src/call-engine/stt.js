const speech = require('@google-cloud/speech')

// Handle Google credentials — support both file path and JSON string (for Render)
function getGoogleCredentials() {
  if (process.env.GOOGLE_APPLICATION_CREDENTIALS_JSON) {
    // Render deployment — credentials passed as JSON string env var
    return JSON.parse(process.env.GOOGLE_APPLICATION_CREDENTIALS_JSON)
  }
  // Local dev — uses GOOGLE_APPLICATION_CREDENTIALS file path
  return undefined
}

const clientOptions = {}
const creds = getGoogleCredentials()
if (creds) clientOptions.credentials = creds

const speechClient = new speech.SpeechClient(clientOptions)

/**
 * Creates a Google STT streaming session.
 *
 * @param {Function} onTranscript - Called with (text, detectedLang) when user finishes speaking
 * @param {Function} onError - Called when STT stream errors
 * @returns {WritableStream} - Write audio buffers to this stream
 */
function createSTTStream(onTranscript, onError) {
  const streamingConfig = {
    config: {
      encoding: 'LINEAR16',
      sampleRateHertz: 8000,       // 8kHz for phone calls
      audioChannelCount: 1,         // Mono
      enableAutomaticPunctuation: true,
      model: 'phone_call',          // Optimized for telephone audio
      useEnhanced: true,            // Better accuracy
      // Multi-language: Gujarati first, then Hindi, then English
      languageCode: 'gu-IN',
      alternativeLanguageCodes: ['hi-IN', 'en-IN'],
    },
    interimResults: false,          // Only final results to avoid double-processing
    singleUtterance: false,         // Keep stream open for full conversation
  }

  const recognizeStream = speechClient
    .streamingRecognize(streamingConfig)
    .on('error', (err) => {
      console.error('[STT] Stream error:', err.message)
      if (onError) onError(err)
    })
    .on('data', (data) => {
      const result = data.results?.[0]
      if (!result?.isFinal) return

      const transcript = result.alternatives?.[0]?.transcript?.trim()
      if (!transcript) return

      // Detect which language Google used
      const langCode = (result.languageCode || 'gu-in').toLowerCase()
      let detectedLang = 'gu'
      if (langCode.startsWith('hi')) detectedLang = 'hi'
      else if (langCode.startsWith('en')) detectedLang = 'en'
      else if (langCode.startsWith('gu')) detectedLang = 'gu'

      console.log(`[STT] (${detectedLang}): "${transcript}"`)
      onTranscript(transcript, detectedLang)
    })

  return recognizeStream
}

/**
 * Voice Activity Detector — detects when user stops speaking.
 * Uses RMS energy of audio to detect silence.
 */
class VoiceActivityDetector {
  constructor(onSilenceDetected, silenceThresholdMs = 800) {
    this.silenceThresholdMs = silenceThresholdMs
    this.onSilenceDetected = onSilenceDetected
    this.isSpeaking = false
    this.silenceTimer = null
    this.ENERGY_THRESHOLD = 300  // Tune this: lower = more sensitive
  }

  processChunk(audioBuffer) {
    const energy = this.calculateRMS(audioBuffer)

    if (energy > this.ENERGY_THRESHOLD) {
      // User is speaking
      this.isSpeaking = true
      if (this.silenceTimer) {
        clearTimeout(this.silenceTimer)
        this.silenceTimer = null
      }
    } else if (this.isSpeaking) {
      // Silence detected after speech
      if (!this.silenceTimer) {
        this.silenceTimer = setTimeout(() => {
          this.isSpeaking = false
          this.silenceTimer = null
          this.onSilenceDetected()
        }, this.silenceThresholdMs)
      }
    }
  }

  calculateRMS(buffer) {
    const samples = new Int16Array(
      buffer.buffer,
      buffer.byteOffset,
      buffer.byteLength / 2
    )
    let sum = 0
    for (let i = 0; i < samples.length; i++) {
      sum += samples[i] * samples[i]
    }
    return Math.sqrt(sum / samples.length)
  }

  destroy() {
    if (this.silenceTimer) clearTimeout(this.silenceTimer)
  }
}

module.exports = { createSTTStream, VoiceActivityDetector }
